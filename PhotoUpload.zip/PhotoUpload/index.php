<html>
    <head>
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/responsive.css" rel="stylesheet" type="text/css">    
    </head>
    <body>
        <div class="head-part">
            <h1>Gallery</h1>
        </div>
        <div class="main-part">
            <form action="dashboard.php" method="post" enctype="multipart/form-data">
                <h3 class="sub-head">Select Photo</h3>
                <input type="file" name="photo" id="photo" class="photo"><br><br>
                <button name="upload"><img class="upload-icon" src="images/upload.svg">Upload</button>
            </form>
        </div>
        <div class="foot-part">
            <h1>Fullstack Challenge - 2020 </h1>
        </div>
    </body>
</html>