<html>
    <head>
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <link href="css/responsive.css" rel="stylesheet" type="text/css">    
    </head>
    <body>
        <div class="head-part2">
            <h1>Gallery</h1>
        </div>
        <div class="main-part2">
                    <?php
                        $con = mysqli_connect('localhost','root');
                        mysqli_select_db($con,'PhotoShare');

                        if(isset($_POST['upload'])){

                        $image = $_FILES['photo'];

                        $photoname = $image['name'];
                        $filerror = $image['error'];
                        $filetmp = $image['tmp_name'];

                        $fileext = explode('.',$photoname);
                        $filecheck = strtolower(end($fileext));

                        $fileextstored = array('png','jpg','jpeg');

                        if(in_array($filecheck,$fileextstored))
                        {
                            //$destinationfile = 'upload/'.$photoname;
                            $destinationfile = $photoname;
                            move_uploaded_file($filetmp,$destinationfile);

                            
                            $q ="INSERT INTO `photodata` (`image`) VALUES ('$destinationfile');";
                            $query = mysqli_query($con,$q);

                            $q1="SELECT * FROM `photodata`";
                            $query1 = mysqli_query($con,$q1);

                            ?>
                            <table>
                            <?php
                            $i=0;
                            while( $result = mysqli_fetch_assoc($query1))
                            {
                                if($i % 3 == 0)
                                {
                                    echo"<tr>";
                                }
                                echo"<td>
                                <div class='display-area'>
                                    <img id='{$result['image']}' src='{$result['image']}' class='gallery preview-image'>
                                    <h3 class='image-name'>{$result['image']}</h3>
                                </div>
                                </td>";
                                if($i % 3 == 2)
                                {
                                    echo"</tr>";
                                }
                                $i++;
                            }
                        }
                        else
                        {
                            echo"<div class='alert'>
                                    <span class='closebtn' onclick='this.parentElement.style.display='none';'>&times;</span>
                                    <strong>Cannot Upload this file</strong>
                                </div>";
                        }
                    }
                            ?>
                            </table>
        </div>
        <div class="foot-part2">
            <h1>Fullstack Challenge - 2020 </h1>
        </div>
    </body>
</html>